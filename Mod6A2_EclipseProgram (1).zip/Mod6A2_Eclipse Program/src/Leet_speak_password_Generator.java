import java.util.Scanner;

public class Leet_speak_password_Generator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a simple lowercase password (8 to 15 characters):");
        String password = scanner.nextLine();

        // Check if the password is within the required length (8 to 15 characters)
        if (password.length() < 8 || password.length() > 15) {
            System.out.println("Password length should be between 8 to 15 characters.");
        } else {
            String leetPassword = "$";

            // Loop through each character in the password and apply leet transformations
            for (char ch : password.toCharArray()) {
                switch (ch) {
                    case 'a':
                        leetPassword += "4";
                        break;
                    case 'e':
                        leetPassword += "3";
                        break;
                    case 'i':
                        leetPassword += "!";
                        break;
                    case 'l':
                        leetPassword += "1";
                        break;
                    case 'o':
                        leetPassword += "0";
                        break;
                    case 's':
                        leetPassword += "5";
                        break;
                    case 't':
                        leetPassword += "7";
                        break;
                    default:
                        leetPassword += ch;
                }
            }

            leetPassword += "*"; // Append "*" to the end of the password
            System.out.println("Your leet password: " + leetPassword);
        }
    }
}

